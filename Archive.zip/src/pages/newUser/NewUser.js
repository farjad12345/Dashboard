import React from 'react'
import "./NewUser.css"
function NewUser() {
  return (
    <div>
      newuser
    </div>
  )
}

export default NewUser
